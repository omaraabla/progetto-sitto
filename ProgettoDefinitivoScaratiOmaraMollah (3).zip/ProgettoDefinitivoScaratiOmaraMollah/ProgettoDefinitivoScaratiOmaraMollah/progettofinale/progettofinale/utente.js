// Legge cookie utente
function leggiCookie(nome) {
  const match = document.cookie.match(new RegExp('(^| )' + nome + '=([^;]+)'));
  return match ? decodeURIComponent(match[2]) : null;
}

const nome = leggiCookie("utente");
const salutoDiv = document.getElementById("saluto");

if (nome) {
  salutoDiv.textContent = `👋 Bentornato ${nome}`;
} else {
  salutoDiv.textContent = "Effettua l’accesso per visualizzare le informazioni.";
}

// Dati simulati
const prenotazioniMock = [
  { data: "2024-05-10", ora: "20:00", persone: 2 },
  { data: "2024-04-22", ora: "19:30", persone: 4 }
];

const ordiniMock = [
  { piatto: "Biryani (Bangladesh)", data: "2024-05-05", totale: 12 },
  { piatto: "Pizza Margherita (Italia)", data: "2024-04-20", totale: 10 }
];

if (nome) {
  const listaPrenotazioni = document.getElementById("listaPrenotazioni");
  prenotazioniMock.forEach(p => {
    const li = document.createElement("li");
    li.textContent = `📅 ${p.data} alle ${p.ora} - ${p.persone} persone`;
    listaPrenotazioni.appendChild(li);
  });

  const listaOrdini = document.getElementById("listaOrdini");
  ordiniMock.forEach(o => {
    const li = document.createElement("li");
    li.textContent = `🛍️ ${o.piatto} - €${o.totale} (${o.data})`;
    listaOrdini.appendChild(li);
  });
}
